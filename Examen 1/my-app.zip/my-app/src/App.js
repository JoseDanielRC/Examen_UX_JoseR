import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Button, ButtonGroup } from 'reactstrap';
import { Table } from 'reactstrap';
import { InputGroup, InputGroupAddon, InputGroupText, Input } from 'reactstrap';
const out = { apunte: "React no sirve", fecha: "21/ago/2020", etiquetas: ["Esta", "Mierda", "Me la pela"] };
function App() {
  
  return (
    
    <div className="App-header">
       <ButtonGroup>
      <Button>Guardar</Button>
      <Input placeholder="Apunte" />
      <Input placeholder="Fecha" />
    <Input placeholder="Etiqueta" />
    </ButtonGroup>
       <Table>
      <thead>
        <tr>
          <th></th>
          <th>Apunte</th>
          <th>Fecha</th>
          <th>Etiquetas</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">1</th>
  <td>{out.apunte}</td>
          <td>{out.fecha}</td>
          <td>react,javascript,front-end</td>
        </tr>
        <tr>
          <th scope="row">2</th>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>@fat</td>
        </tr>
        <tr>
          <th scope="row">3</th>
          <td>Larry</td>
          <td>the Bird</td>
          <td>@twitter</td>
        </tr>
      </tbody>
    </Table>

    </div>
    
  
  );
  }
export default App;
